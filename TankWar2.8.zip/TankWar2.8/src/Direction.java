
public enum Direction {
	L, LU, U, RU, R, RD, D, LD, STOP
}
