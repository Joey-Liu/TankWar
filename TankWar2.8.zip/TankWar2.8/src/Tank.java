import java.awt.*;
import java.util.*;
import java.awt.event.KeyEvent;
import java.util.*;
public class Tank {
	public static final int XSPEED = 7;
	public static final int YSPEED = 7;
		
	private int life = 100;
	private BloodBar bb = new BloodBar();
	
	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	private static Random r = new Random();
	TankClient tc;
	
	private boolean good;
	
	public boolean isGood() {
		return good;
	}

	private boolean live = true;
	
	public boolean isLive() {
		return live;
	}

	public void setLive(boolean live) {
		this.live = live;
	}
	
	/**
	 * �õ�Ĭ�ϵĹ��߰�	ʹ�øö������һϵ�� ���ʺ�javaֱ������ ����
	 */
	private static Toolkit tk = Toolkit.getDefaultToolkit();
	/**
	 * ��ըͼƬ
	 */
	private static Image tankImages[] = null;
	private static Map<String, Image> imgs = new HashMap<String, Image>();
	
	static{
		tankImages = new Image[] {
			tk.getImage((new Tank(1,3,false)).getClass().getClassLoader().getResource("images/tankL.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankLU.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankU.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankRU.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankR.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankRD.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankD.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankLD.gif")),
			tk.getImage(Tank.class.getClassLoader().getResource("images/tankL.gif"))
			
		};
		
		imgs.put("L", tankImages[0]);
		imgs.put("LU", tankImages[1]);
		imgs.put("U", tankImages[2]);
		imgs.put("RU", tankImages[3]);
		imgs.put("R", tankImages[4]);
		imgs.put("RD", tankImages[5]);
		imgs.put("D", tankImages[6]);
		imgs.put("LD", tankImages[7]);
		
	//	System.out.println(tankImages[0].getWidth(null));
	//	System.out.println(tankImages[0].getHeight(null));
		
	}

	public static final int WIDTH = 30;
	public static final int HEIGHT = 30;
	
	private int x, y;
	private int oldX, oldY;
	
	private boolean bL = false, bU = false,bR = false,bD = false;
	
	//enum Direction {L, LU, U, RU, R, RD, D, LD, STOP};
	
	private Direction dir = Direction.STOP;
	
	private Direction ptDir = Direction.D;
	
	private int step = r.nextInt(12) + 3;//��С�ƶ�5��
	public Tank(int x, int y,boolean good) {
		this.x = x;
		this.y = y;
		this.oldX = x;
		this.oldY = y;
		this.good = good;
	}
	
	public Tank(int x,int y,boolean good, Direction dir, TankClient tc)
	{
		this(x,y,good);
		this.dir = dir;
		this.tc = tc;
	}
	
	public void draw(Graphics g)
	{
		if(!live)
		{
			if(!good)
			{
				tc.tanks.remove(this);
			}
			return;
		}
//		Color c = g.getColor();
//		if(good)
//			g.setColor(Color.RED);
//		else
//			g.setColor(Color.blue);
//		//g.fillOval(x, y, WIDTH, HEIGHT);
		//g.setColor(c);
		
		switch(ptDir) {
		case L:
			g.drawImage(imgs.get("L"), x, y, null);
			break;
		case LU://�е㲻����
			g.drawImage(imgs.get("LU"), x, y, null);
			break;
		case U:
			g.drawImage(imgs.get("U"), x, y, null);
			break;
		case RU:
			g.drawImage(imgs.get("RU"), x, y, null);
			break;
		case R:
			g.drawImage(imgs.get("R"), x, y, null);
			break;
		case RD:
			g.drawImage(imgs.get("RD"), x, y, null);
			break;
		case D:
			g.drawImage(imgs.get("D"), x, y, null);
			break;
		case LD:
			g.drawImage(imgs.get("LD"), x, y, null);
			break;
		}
		//if(this.good)
			bb.draw(g);
		move();
	}
	
	void move()
	{
		this.oldX = x;
		this.oldY = y;
		
		switch(dir) {
		case L:
			x -= XSPEED;
			break;
		case LU://�е㲻����
			x -= XSPEED;
			y -= YSPEED;
			break;
		case U:
			y -= XSPEED;
			break;
		case RU:
			x += XSPEED;
			y -= YSPEED;
			break;
		case R:
			x += XSPEED;
			break;
		case RD:
			x += XSPEED;
			y += YSPEED;
			break;
		case D:
			y += XSPEED;
			break;
		case LD:
			x -= XSPEED;
			y += YSPEED;
			break;
		case STOP:
			break;
		}
		
		if(this.dir != Direction.STOP)
			this.ptDir = this.dir;
		if(x < 0)
			x = 0;
		if(y < 30)
			y = 30;
		
		if(x + Tank.WIDTH > TankClient.GAME_WIDTH)
			x = TankClient.GAME_WIDTH - Tank.WIDTH;
		if(y + Tank.HEIGHT > TankClient.GAME_HEIGHT)
			y = TankClient.GAME_HEIGHT - Tank.HEIGHT;
		
		if(!good)
		{
			Direction dirs[] = Direction.values();
			if(0==step)
			{
				int rn = r.nextInt(dirs.length);
				step = r.nextInt(2) + 10;
				this.dir = dirs[rn];
			}
			step--;
			if(r.nextInt(40) > 37)
				fire();
		}
	}
	
	private void stay()
	{
		this.x = this.oldX;
		this.y = this.oldY;
	}
	
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		switch(key) {
		case KeyEvent.VK_LEFT:
			bL = true;
			break;
		case KeyEvent.VK_UP:
			bU = true;
			break;
		case KeyEvent.VK_RIGHT:
			bR = true;
			break;
		case KeyEvent.VK_DOWN:
			bD = true;
			break;
		case KeyEvent.VK_F2:
			if(!tc.myTank.isLive())
			{
				tc.myTank.setLife(100);
				tc.myTank.setLive(true);
			}
		}
		//���°����� ��λ���� 
		locateDirection();
	}
	
	void locateDirection() {
		if(bL && !bU && !bR && !bD ) dir = Direction.L;
		else if(!bL && bU && !bR && !bD ) dir = Direction.U;
		else if(!bL && !bU && bR && !bD ) dir = Direction.R;
		else if(!bL && !bU && !bR && bD ) dir = Direction.D;
		else if(bL && bU && !bR && !bD ) dir = Direction.LU;
		else if(bL && !bU && !bR && bD ) dir = Direction.LD;
		else if(!bL && bU && bR && !bD ) dir = Direction.RU;
		else if(!bL && !bU && bR && bD ) dir = Direction.RD;
		else if(!bL && !bU && !bR && !bD ) dir = Direction.STOP;
		
	}
	
	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		switch(key) {
		case KeyEvent.VK_LEFT:
			bL = false;
			break;
		case KeyEvent.VK_UP:
			bU = false;
			break;
		case KeyEvent.VK_RIGHT:
			bR = false;
			break;
		case KeyEvent.VK_DOWN:
			bD = false;
			break;
		case KeyEvent.VK_CONTROL:
			//tc.missiles.add(fire());
			fire();
			break;
		case KeyEvent.VK_A:
			superFire();
			break;
		}
		//���°����� ��λ���� 
		locateDirection();
	}
	
	public Missile fire()
	{
		if(!live)
			return null;
		int x = this.x + Tank.WIDTH / 2 - Missile.WIDTH / 2;
		int y = this.y + Tank.HEIGHT / 2 - Missile.HEIGHT / 2;
		Missile m = new Missile(x, y,this.good, ptDir,tc);
		tc.missiles.add(m);
		return m;
	}
	
	public Missile fire(Direction dir)
	{
		if(!live)
			return null;
		int x = this.x + Tank.WIDTH / 2 - Missile.WIDTH / 2;
		int y = this.y + Tank.HEIGHT / 2 - Missile.HEIGHT / 2;
		Missile m = new Missile(x, y,this.good, dir, tc);
		tc.missiles.add(m);
		return m;
	}
	
	public Rectangle getRectangle()
	{
	//	System.out.println(tankImages[0].getWidth(null));
		return new Rectangle(x,y,WIDTH, HEIGHT);
	}
	
	/**
	 * ײǽ
	 * @param w ��ײ��ǽ
	 * @return ײ�Ϸ���true ���� false
	 */
	public boolean collidsWithWall(Wall w)
	{
		if(this.live && this.getRectangle().intersects(w.getRect()) )
		{
			//this.dir = Direction.STOP;
			this.stay();
			return true;
		}
		return false;
	}
	
	public boolean collidsWithTanks(java.util.List<Tank> tanks)
	{
		for(int i = 0;i < tanks.size();i++)
		{
			Tank t = tanks.get(i);
			if(this != t)
			{
				if(this.live && t.isLive() && t.getRectangle().intersects(this.getRectangle()) )
				{
					this.stay();
					t.stay();
					return true;
				}
			}//if this != t
		}
		return false;
	}
	
	private void superFire()
	{
		Direction dirs[] = Direction.values();
		for(int i = 0;i < dirs.length - 1;i++)
		{
			fire(dirs[i]);
		}
	}
	
	private class BloodBar {
		public void draw(Graphics g)
		{
			Color c = g.getColor();
			g.setColor(Color.RED);
			g.drawRect(x + 8, y, WIDTH, 10);
			
			int w = WIDTH * life / 100;
			g.fillRect(x + 8, y, w, 10);
			g.setColor(c);
		}
	}
	
	public boolean eat(Blood b)
	{
		if(this.live && b.isLive() && 
				this.getRectangle().intersects(b.getRect()))
		{
			this.setLife(100);
			b.setLive(false);
			return true;
		}
		return false;
	}
}
