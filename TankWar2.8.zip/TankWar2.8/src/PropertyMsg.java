import java.io.*;
import java.util.*;


public class PropertyMsg {
	static Properties props = new Properties();
	
	static {
		try {
			props.load(PropertyMsg.class.getClassLoader().getResourceAsStream("config/tank.properties"));
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	public static String getProperties(String key)
	{
		return props.getProperty(key);
	}
	/**
	 * ���� ������ ��������
	 */
	private PropertyMsg() {;}
}
