import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

//ʹ��˫���� ������˸����

/**
 * ������������ ̹����Ϸ��������
 * @author Joey Liu
 *
 */
public class TankClient extends Frame {
	/**
	 * ����̹����Ϸ�Ŀ���
	 */
	public static final int GAME_WIDTH = 800;
	public static final int GAME_HEIGHT = 600;

	Tank myTank = new Tank(50, 50,true, Direction.STOP,this);
	//Tank enemyTank  = new Tank(100, 100,false,this);
	//Explode e = new Explode(70, 70, this);
	Wall w1 = new Wall(100,200,20,150,this), w2 = new Wall(300,100,300,20,this);
	
	List<Missile > missiles = new LinkedList<Missile >();
	List<Explode > explodes = new LinkedList<Explode >();
	List<Tank > tanks = new LinkedList<Tank >();
	Map<Tank, String> taknks  = new TreeMap<Tank, String >();
	
	Blood b = new Blood();
	Image offScreenImage = null; // ���������ͼƬ

	// �ػ� ����Ҫֱ�ӵ���
	public void paint(Graphics g) {
		g.drawString("Missiles count: " + missiles.size(), 10,50);
		g.drawString("Explodes count: " + explodes.size(), 10, 70);
		g.drawString("Tanks count: " + tanks.size(), 10, 90);
		g.drawString("Tank's life: " + myTank.getLife(), 10, 110);
		
		String str = new String("Heloo");
		if(tanks.size() <= 0)
		{
			for(int i = 0;i < Integer.parseInt(PropertyMsg.getProperties("reProduceTankCount") );i++)
				tanks.add(new Tank(50 + 40 *( 1 + i),50,false,Direction.D,this));
		}
		
		for(int i = 0 ;i < missiles.size();i++)
		{
			Missile m = missiles.get(i);
			m.hitTanks(tanks);
			m.hitTank(myTank);
			m.hitWall(w1);
			m.hitWall(w2);
			//m.hitTank(enemyTank);
			//if(!m.isLive())
			//	missiles.remove(m);
			//else
			m.draw(g);
		}
		
		for(int i = 0;i < explodes.size();i++)
		{
			Explode e = explodes.get(i);
			e.draw(g);
		}
		
		for(int i = 0;i < tanks.size();i++)
		{
			Tank t = tanks.get(i);		
			t.collidsWithWall(w1);
			t.collidsWithWall(w2);
			t.collidsWithTanks(tanks);
			t.draw(g);
		}
		//e.draw(g);
		b.draw(g);
		myTank.draw(g);
		myTank.collidsWithWall(w1);
		myTank.collidsWithWall(w2);
		myTank.eat(b);
		w1.draw(g);;
		w2.draw(g);
		//enemyTank.draw(g);
	}

	public void update(Graphics g) {
		if (null == offScreenImage) {
			offScreenImage = this.createImage(GAME_WIDTH, GAME_HEIGHT);
		}

		// ��ͼƬ�ں��� �ػ�
		Graphics gOffScreen = offScreenImage.getGraphics();
		Color c = gOffScreen.getColor();
		gOffScreen.setColor(Color.black);
		gOffScreen.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
		gOffScreen.setColor(c);

		paint(gOffScreen);// ��ͼ
		g.drawImage(offScreenImage, 0, 0, null);// ��ʾ��ǰ��
	}
/**
 * ��������ʾ̹��������
 */
	public void lauchFrame() {
		
	
		Properties pros = new Properties();
		try {
			pros.load(this.getClass().getClassLoader().getResourceAsStream("config/tank.properties"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		int initTankCount = Integer.parseInt(PropertyMsg.getProperties("initTankCount") );
		for(int i = 0;i < initTankCount;i++)
		{
			tanks.add(new Tank(50 + 40 *( 1 + i),50,false,Direction.D,this));
		}
		
		this.setLocation(200, 100);
		this.setSize(GAME_WIDTH, GAME_HEIGHT);
		this.setTitle("TankWar");
		this.addWindowListener(new WindowAdapter() {

			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		this.setResizable(false);
		this.setBackground(Color.GREEN);

		this.addKeyListener(new KeyMonitor());

		setVisible(true);

		new Thread(new PaintThread()).start();
	}

	public static void main(String[] args) {

		TankClient to = new TankClient();
		to.lauchFrame();
	}

	// �ػ���
	private class PaintThread implements Runnable {
		public void run() {
			while (true) {
				repaint();
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}// while
		}
	}// private class PaintThread

	private class KeyMonitor extends KeyAdapter {

		public void keyReleased(KeyEvent e) {
			myTank.keyReleased(e);
		}

		//
		public void keyPressed(KeyEvent e) {
			myTank.keyPressed(e);
		}// public
		
		

	}// private keymonitor
}
